﻿namespace CommeChezSwaMylanCoudeville.Models
{
    public class MenuTypeViewModel
    {
        public Menu GeselecteerdMenu { get; set; }
        public IEnumerable<Menu> Menus { get; set; }
    }
}
