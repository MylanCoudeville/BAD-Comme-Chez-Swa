﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommeChezSwaMylanCoudeville.Models
{
    public class Gerecht
    {
        public string Naam { get; set; }
        public double Prijs { get; set; }
        public bool IsVeggie { get; set; }

    }
}
